package com.company;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        int [] Num; // массив последовательности
        int count1; // счетчик числа элементов в массиве
        Scanner scanner = new Scanner(System.in); // подключение нового сканнера

        System.out.println("Введите количество чисел последовательности");
        count1 = scanner.nextInt(); // ввод числа элементов последовательности

        Num = new int [count1]; // задаем размерность массива

        for (int i = 0; i < count1; i++) { // цикл ввода элементов последовательности в массив Num до его конечного размера count1
            System.out.println("Введите " + (i+1) + " число последовательности");
            Num[i] = scanner.nextInt();
        }
        for (int i = 0; i < count1; i++) {
            ArrayList<Integer> digits = new ArrayList<>();
            digits.add(Num[i]);
            System.out.println(digits);
            int [] Element = function(Num [i]);
        }


    }
    public static int[] function (int x) { // функция для разбиения числа на массив из его цифр
        String s = Integer.toString(x);
        int[] Arr = new int[s.length()];
        for (int i = s.length() - 1; i >= 0; i--) {
            Arr[i] = x % 10;
            x /= 10;
        }
        return Arr;
    }
}
